﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10108243_NikkiGordhan_PROG6212_PoE_Part2
{
    class Login
    {
        public string sStudent_Number;
        // creates a variable that can be accessed anywhere within the project called sStudent_Number that stores the student number and its data type which is string.
        public string Student_Number
        {
            get { return sStudent_Number; }
            set { sStudent_Number = value; }
        }
        //getters and setters using automatic properties for Student Number.

        public string sPassword;
        // creates a variable that can be accessed anywhere within the project called sPassword that stores the student password and its data type which is string.
        public string Password
        {
            get { return sPassword; }
            set { sPassword = value; }
        }
        //getters and setters using automatic properties for Student Password.
    }
}
