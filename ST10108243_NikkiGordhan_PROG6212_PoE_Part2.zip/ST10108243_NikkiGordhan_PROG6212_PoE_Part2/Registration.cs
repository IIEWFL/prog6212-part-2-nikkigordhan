﻿namespace ST10108243_NikkiGordhan_PROG6212_PoE_Part2
{
    class Registration
    {
        public string sStudent_Name;
        // creates a variable that can be accessed anywhere within the project called sStudent_Name that stores the student name and its data type which is string.
        public string Student_Name
        {
            get { return sStudent_Name; }
            set { sStudent_Name = value; }
        }
        //getters and setters using automatic properties for Student Name.

        public string sStudent_Number;
        // creates a variable that can be accessed anywhere within the project called sStudent_Number that stores the student number and its data type which is string.
        public string Student_Number
        {
            get { return sStudent_Number; }
            set { sStudent_Number = value; }
        }
        //getters and setters using automatic properties for Student Number.

        public string sSemester;
        // creates a variable that can be accessed anywhere within the project called sStudent_Number that stores the student email and its data type which is string.
        public string Semester
        {
            get { return sSemester; }
            set { sSemester = value; }
        }
        //getters and setters using automatic properties for Student Email.

        public string sPassword;
        // creates a variable that can be accessed anywhere within the project called sPassword that stores the student password and its data type which is string.
        public string Password
        {
            get { return sPassword; }
            set { sPassword = value; }
        }
        //getters and setters using automatic properties for Student Password.

        public string sConfrimed_Password;
        // creates a variable that can be accessed anywhere within the project called sConfrimed_Password that stores the student's confrimed password and its data type which is string.
        public string Confrimed_Password
        {
            get { return sConfrimed_Password; }
            set { sConfrimed_Password = value; }
        }
        //getters and setters using automatic properties for Student Confirmed Password.
    }
}
