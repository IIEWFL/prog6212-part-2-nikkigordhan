﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10108243_NikkiGordhan_PROG6212_PoE_Part1
{
    class Validations
    {
        public string Validate_Semester(string sSemester_Name, int iNo_Weeks)
        {
            
            string sSemesterMsg = "";
            if (sSemester_Name == "")
            {
                sSemesterMsg = sSemesterMsg + "Semester Name is invalid.";
            }
            if (iNo_Weeks < 0)
            {
                sSemesterMsg = sSemesterMsg + "Number of Weeks is invalid.";
            }        
            return sSemesterMsg;
        }
        // method that validates the capturing of the Semester details.
        public string Validate_Module(string sModule_Code, string sModule_Name, int iNo_Credits, int iClass_Hours)
        {
            string sModuleMsg = "";
            if(sModule_Code == "")
            {
                sModuleMsg = sModuleMsg + "Module Code is invalid.";
            }
            if(sModule_Name == "")
            {
                sModuleMsg = sModuleMsg + "Module Name is invalid.";
            }
            if (iNo_Credits < 0)
            {
                sModuleMsg = sModuleMsg + "Number of Credits is invalid.";
            }
            if(iClass_Hours < 0)
            {
                sModuleMsg = sModuleMsg + "Number of Class Hours is invalid.";
            }
            return sModuleMsg;
        }
        // method that validates the capturing of the Module details.
        
        public string Validate_Study_Session(int iAllocated_Study_Hours)
        {
            string sStudyMsg = "";
            if(iAllocated_Study_Hours < 0)
            {
                sStudyMsg = sStudyMsg + "Number of Allocated Study Hours is invalid.";
            }
            return sStudyMsg;  
        }
        // metahod that validates the caputring of the Study Sessions details.

        public string Validate_User(string sStudent_Name, string sStudent_Number, string sSemester, string sPassword, string sConfirm_Paswword)
        {

            string sUserMsg = "";
            if (sStudent_Name == "")
            {
                sUserMsg = sUserMsg + "Student Name is invalid.";
            }
            if (sStudent_Number == "")
            {
                sUserMsg = sUserMsg + "Student Number is invalid.";
            }
            if (sSemester == "")
            {
                sUserMsg = sUserMsg + "Plaese select a semester.";
            }
            if (sPassword == "")
            {
                sUserMsg = sUserMsg + "Password is invalid.";
            }
            if(sConfirm_Paswword == "")
            {
                sUserMsg = sUserMsg + "Password is invalid.";
            }
            if (sPassword != sConfirm_Paswword)
            {
                sUserMsg = sUserMsg + "Password does not match.";
            }
            // check the database if user exists with a where.
            return sUserMsg;
        }
        // method that validates the capturing of the User/Student details.

        public string Validate_Login(string sStudent_Number,string sPassword)
        {
            string sUserMsg = "";
            if (sStudent_Number == "")
            {
                sUserMsg = sUserMsg + "Student Number is invalid.";
            }
            if (sPassword == "")
            {
                sUserMsg = sUserMsg + "Password is invalid.";
            }
            return sUserMsg;
        }
        // validates the login.
    }
    // class that Validates each of the respective objects when saving the object.
}
