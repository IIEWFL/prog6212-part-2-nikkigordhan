﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net.PeerToPeer.Collaboration;


//https://stackoverflow.com/questions/13410210/creating-a-class-to-interact-with-a-sql-database

public class AccessData
{
     public string connectionString = "Data Source = localhost; Initial Catalog = PROG6212_PoE_Part2; uid = nikki; pwd = VC2023!";
    //creates a connection string.

    //string connectionString = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;

    public bool RegisterUser(string sStudent_Name, string sStudent_Number, string sSemester, string sHashed_Password)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            string sql = "INSERT INTO RegisterUser (Student_Name,Student_Number, Semester_Name, Password ) " +
                "VALUES ('" + sStudent_Name + "','" + sStudent_Number + "','" + sSemester + "','" + sHashed_Password + "' )";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                int rowsAffected = command.ExecuteNonQuery();
                return rowsAffected > 0;

            }
        }
    }
    //inserts into the RegisterUser table.


    public bool Insert_Semester(string sSemester_Name, DateTime dStart_Date, int iNumber_Of_Weeks)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            string sql = "INSERT INTO Semester ( Semester_Name, Start_Date, Number_Of_Weeks) " +
                         "VALUES ('" + sSemester_Name + "','" + dStart_Date + "','" + iNumber_Of_Weeks + "' )";
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                int rowsAffected = command.ExecuteNonQuery();
                return rowsAffected > 0;

                
            }
        }
    }
    //inserts into the Semester table.

     public bool Insert_Module(string sModule_Code, string sModule_Name, int iNumber_Of_Credits, int iClass_Hours)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {

            connection.Open();

            string sql = "INSERT INTO Module (Module_Code, Module_Name, Number_Of_Credits, Class_Hours) " +
                         "VALUES ('" + sModule_Code + "','" + sModule_Name + "','" + iNumber_Of_Credits + "','" + iClass_Hours + "' )";
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                int rowsAffected = command.ExecuteNonQuery();
                return rowsAffected > 0;

            }
        }
    }
    //inserts into the Module table.

    public bool Insert_Login(string sStudent_Number, string sPassword)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {

            connection.Open();

            string sql = "INSERT INTO LoginUser (Student_Number, Password) " +
                         "VALUES ('" + sStudent_Number + "','" + sPassword + "' )";
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                int rowsAffected = command.ExecuteNonQuery();
                return rowsAffected > 0;

            }
        }
    }

    public bool InsertAMTS(string sSemester, string sAssinged_Modules)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            string sql = "INSERT INTO AddModulesToSemester (Semester_Name, Assigned_Modules ) " +
                "VALUES ('" + sSemester + "','" + sAssinged_Modules + "' )";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                int rowsAffected = command.ExecuteNonQuery();
                return rowsAffected > 0;

            }
        }
    }

    public bool InsertMTS(string sModule_Code, string sSemester_Name, string sSelf_Study_Hrs)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            string sql = "INSERT INTO SemesterModules (Module_Code,Semester_Name,Self_Study_Hrs ) " +
                "VALUES ('" + sModule_Code + "','" + sSemester_Name + "'," + sSelf_Study_Hrs + " )";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                int rowsAffected = command.ExecuteNonQuery();
                return rowsAffected > 0;

            }
        }
    }


    public bool InsertSS(string sStudent_Number, string sSemester_Name, string sModule_Code, string sAllocated_Study_Hours, DateTime dStudyDate, string sSelf_Study_Hours, string sRemaining_Hours)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            string sql = "INSERT INTO StudySession (Student_Number,Semester_Name,Module_Code,Allocated_Hours,Study_Date,Self_Study_Hours,Hours_Remaining) " +
                         "VALUES ('" + sStudent_Number + "','" + sSemester_Name + "','" + sModule_Code + "','" + sAllocated_Study_Hours + "','" + dStudyDate + "','" + sSelf_Study_Hours + "','" + sRemaining_Hours + "' )";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                int rowsAffected = command.ExecuteNonQuery();
                return rowsAffected > 0;

            }
        }
    }

    public bool InsertMP(string sStudent_Number, string sSemester_Name, string sModule_Code,  string sSelf_Study_Hours, string sRemaining_Hours, string sTotal_Study_Hours)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            string sql = "INSERT INTO StudentModuleProgress (Student_Number,Module_Code,Semester_Name,Self_Study_Hours,Remaining_Hours,Total_Study_Hours,Date_Inserted) " +
                         "VALUES ('" + sStudent_Number + "','" + sSemester_Name + "','" + sModule_Code + "','" + sSelf_Study_Hours + "','" + sRemaining_Hours + "','" + sTotal_Study_Hours + "' )";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                int rowsAffected = command.ExecuteNonQuery();
                return rowsAffected > 0;

            }
        }
    }

    public DataTable ExecuteSelectQuery(string query)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                DataTable dataTable = new DataTable();
                dataTable.Load(command.ExecuteReader());
                return dataTable;
            }
        }
    }

    public void ExecuteInsertUpdateQuery(string query)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

}


